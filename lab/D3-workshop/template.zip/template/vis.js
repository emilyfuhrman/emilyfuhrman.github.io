/* ------------------------------------------------------------------
 TEMPLATE
 -------------------------------------------------------------------- */

var w = window.innerWidth,
	h = window.innerHeight;

/*var svg = d3.select("#vis")
	.append("svg")
	.attr("width",w)
	.attr("height",h);*/